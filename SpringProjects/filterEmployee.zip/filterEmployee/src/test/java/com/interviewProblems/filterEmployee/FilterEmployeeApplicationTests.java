package com.interviewProblems.filterEmployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilterEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
